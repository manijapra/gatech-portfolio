/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=4 titlescreen titlescreen.bmp 
 * Time-stamp: Saturday 11/07/2015, 22:18:07
 * 
 * Image Information
 * -----------------
 * titlescreen.bmp 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef TITLESCREEN_H
#define TITLESCREEN_H

extern const unsigned short titlescreen_palette[255];
#define TITLESCREEN_PALETTE_SIZE 255

extern const unsigned short titlescreen[19200];
#define TITLESCREEN_SIZE 19200
#define TITLESCREEN_WIDTH 240
#define TITLESCREEN_HEIGHT 160

#endif

