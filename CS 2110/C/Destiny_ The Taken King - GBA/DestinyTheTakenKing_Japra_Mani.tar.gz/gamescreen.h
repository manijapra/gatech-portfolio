/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=4 gamescreen gamescreen.bmp 
 * Time-stamp: Saturday 11/07/2015, 22:18:58
 * 
 * Image Information
 * -----------------
 * gamescreen.bmp 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef GAMESCREEN_H
#define GAMESCREEN_H

extern const unsigned short gamescreen_palette[255];
#define GAMESCREEN_PALETTE_SIZE 255

extern const unsigned short gamescreen[19200];
#define GAMESCREEN_SIZE 19200
#define GAMESCREEN_WIDTH 240
#define GAMESCREEN_HEIGHT 160

#endif

