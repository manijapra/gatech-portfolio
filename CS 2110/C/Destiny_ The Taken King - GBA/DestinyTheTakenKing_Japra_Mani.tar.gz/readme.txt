DESTINY: THE TAKEN KING
-----------------------

Created By: Mani Japra (902958199)

Premise:
--------

Guardian, the traveler is in grave danger! The Taken King, Oryx, has come to destroy anything in its path to avenge his son, Crota.

Use your ship and defeat the Taken King before it's too late!

You are all that stands between Oryx and the Traveler.


Gameplay Instructions:
----------------------

1) Upon startup, you will see that you must press 'A' to begin the game.
2) Once the game has begun, you can control your ship by using the UP, DOWN, RIGHT, LEFT keys.
3) To shoot your blaster at any time, press the 'A' button.
4) Your goal, should you choose to accept it, is to defeat the Oryx.
5) Press the 'Select' button at any time to return to the main menu.
