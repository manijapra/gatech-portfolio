#define STARWARSTITLESCREEN_WIDTH 240
#define STARWARSTITLESCREEN_HEIGHT 160
const unsigned short StarWarsTitleScreen_data[38400];
