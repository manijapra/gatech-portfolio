#define SHIPLEFT_WIDTH 40
#define SHIPLEFT_HEIGHT 40
const unsigned short shipleft_data[1600];
