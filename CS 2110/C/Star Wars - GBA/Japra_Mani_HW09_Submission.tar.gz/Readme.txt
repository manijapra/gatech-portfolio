STAR WARS
---------

Created By: Mani Japra (902958199)

Premise:
--------

You have cornered Darth Vader in his tie fighter in a galaxy far far away! You have been awaiting this day for years and it has finally come. Your mission, should you choose to accept it, is to defeat Darth Vader and bring peace to the galaxy!

May the Force be with you, Jedi!


Gameplay Instructions:
----------------------

1) Upon startup, you will see that you must press 'A' to begin the game.
2) Once the game has begun, you can control the milennium falcon by using the UP, DOWN, RIGHT, LEFT keys.
3) To shoot your blaster at any time, press the 'A' button.
4) Your goal, should you choose to accept it, is to defeat the Tie Fighter.
	- NOTE: The Tie Fighter is one strong ship and has to be hit multiple times to die.
		The Health bar of the tie fighter is on the top right.
5) Press the 'Select' button at any time to return to the main menu.
