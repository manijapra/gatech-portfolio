#define THIRDHEALTH_WIDTH 30
#define THIRDHEALTH_HEIGHT 14
const unsigned short thirdhealth_data[420];
