#define LOWHEALTH_WIDTH 30
#define LOWHEALTH_HEIGHT 14
const unsigned short lowhealth_data[420];
