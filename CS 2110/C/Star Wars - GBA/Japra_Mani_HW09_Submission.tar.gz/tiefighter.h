#define TIEFIGHTER_WIDTH 25
#define TIEFIGHTER_HEIGHT 25
const unsigned short tiefighter_data[625];
