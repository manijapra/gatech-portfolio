#define SHIPRIGHT_WIDTH 40
#define SHIPRIGHT_HEIGHT 40
const unsigned short shipright_data[1600];
