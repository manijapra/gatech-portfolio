#define FULLHEALTH_WIDTH 30
#define FULLHEALTH_HEIGHT 14
const unsigned short fullhealth_data[420];
