#define SHIPDOWN_WIDTH 40
#define SHIPDOWN_HEIGHT 40
const unsigned short shipdown_data[1600];
