#define SHIPUP_WIDTH 40
#define SHIPUP_HEIGHT 40
const unsigned short shipup_data[1600];
