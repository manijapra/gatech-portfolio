#define WINSCREEN_WIDTH 240
#define WINSCREEN_HEIGHT 160
const unsigned short winscreen_data[38400];
